<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body style="max-width: 720px;width: 100%;margin:auto;margin-bottom: 1em;margin-top: 1em;border: 1px solid #cdcdcd;padding-bottom: 2em;padding-right: 2em;padding-left: 2em;font-family: sans-serif;">
	<div style="text-align: center; padding:2em;">
		<img src="http://api.lokaldatph.com/img/logo-gold.png" style="margin: auto; height: 50px;width: auto;object-fit: contain;">
	</div>
	<div style="width: 100%;text-align: center">
		<span style="font-size: 24px;color:#1682ba">Thank you for shopping!</span>
	</div>
	<div style="width: 100%;text-align: justify;margin-top: 1em;margin-bottom:1em;color:#4a4a4a">
		<span style="font-size: 18px">Hi <?php echo e($client_name); ?> ,</span>
		<p>We received your <strong><?php echo e($order_no); ?></strong> on <strong><?php echo e($order_date); ?></strong> and you'll be paying for this via <strong><?php echo e($payment_method); ?></strong>. We’re getting your order ready and will let you know once it’s on the way. We wish you enjoy shopping with us and hope to see you again real soon!</p>
	</div>
	<div style="height: 3px;background-color: #cdcdcd;margin-top: 1em;margin-bottom: 1em"></div>
	<div style="width: 100%;color:#4a4a4a">
		<img src="http://api.lokaldatph.com/img/pin.png" style="width: 40px; height: 40px; object-fit: contain;margin-top: 1em">
		<span style="font-size: 18px;margin-top: 27px;position: absolute;margin-left: 0.5em;">Your delivery details</span>
		<table width="100%" cellpadding="5" style="margin-top:1em">
			<tr>
				<td width="25%" style="color:#1682ba">Name</td>
				<td><?php echo e($client_name); ?></td>
			</tr>
			<tr>
				<td width="25%" style="color:#1682ba">Address</td>
				<td><?php echo e($client_address); ?></td>
			</tr>
			<tr>
				<td width="25%" style="color:#1682ba">Contact</td>
				<td><?php echo e($client_contact); ?></td>
			</tr>
			<tr>
				<td width="25%" style="color:#1682ba">Email</td>
				<td style="color:blue"><?php echo e($client_email); ?></td>
			</tr>
		</table>
	</div>
	<?php $__currentLoopData = $order_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div style="height: 3px;background-color: #cdcdcd;margin-top: 1em;margin-bottom: 1em"></div>
	<div style="width: 100%;color:#4a4a4a;margin:0.5em">
		<img src="http://api.lokaldatph.com/img/cart.png" style="width: 40px; height: 40px; object-fit: contain;margin-top: 15px">
		<span style="font-size: 18px;margin-top: 27px;position: absolute;margin-left: 0.5em;">Item(s) <?php echo e(number_format($order['total_qty'], 0)); ?></span>
	</div>
	<div style="width: 100%;color:#4a4a4a">
		<span style="">Sold By: <?php echo e($order['seller']); ?></span>
		<table width="100%" cellpadding="5">
			<?php $__currentLoopData = $order['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td width="35%">
					<img src="<?php echo e($items['product_image']); ?>" style="width: 200px;height: 200px;object-fit: contain;">
				</td>
				<td style="padding:2em;vertical-align: top">
					<span><?php echo e($items['product_name']); ?></span><br>
					<span style="color:red">₱ <?php echo e(number_format($items['selling_price'], 2)); ?></span><br>
					<span>Qty : <?php echo e($items['order_qty']); ?></span>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div style="height: 3px;background-color: #cdcdcd;margin-top: 1em;margin-bottom: 15px"></div>
	<div style="width: 100%;color:#4a4a4a">
		<table width="100%" cellpadding="5">
			<tr>
				<td width="75%">Subtotal</td>
				<td width="5%">₱</td>
				<td style="text-align: right"><?php echo e(number_format($subtotal, 2)); ?></td>
			</tr>
			<tr>
				<td width="75%">Shipping Fee</td>
				<td width="5%">₱</td>
				<td style="text-align: right"><?php echo e(number_format($total_shipping, 2)); ?></td>
			</tr>
			<tr>
				<td width="75%">Total Discounts</td>
				<td width="5%">₱</td>
				<td style="text-align: right"><?php echo e(number_format($total_discount, 2)); ?></td>
			</tr>
			<tr>
				<td width="75%">Total (Tax Included)</td>
				<td width="5%">₱</td>
				<td style="text-align: right;background-color: #efc501;color: red"><?php echo e(number_format($total, 2)); ?></td>
			</tr>
		</table>
	</div>
	<div style="height: 1px;background-color: #cdcdcd;margin-top: 1em;margin-bottom: 1em"></div>
	<div style="width: 100%;color:#4a4a4a">
		<table width="100%" cellpadding="5">
			<tr>
				<td width="50%">Courier</td>
				<td style="text-align: right;"><?php echo e($courier); ?></td>
			</tr>
			<tr>
				<td width="50%">Payment Method</td>
				<td style="text-align: right;"><?php echo e($payment_method); ?></td>
			</tr>
		</table>
	</div>
</body>
</html><?php /**PATH C:\laragon\www\lokalapi\resources\views/mails/order.blade.php ENDPATH**/ ?>
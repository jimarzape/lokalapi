<?php

namespace App\Http\Controllers\Courier;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class NinjaVanController extends Controller
{
    public function check_fee(Request $request)
    {

    }
}
